import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getAbnormalMarker(result: string, range: string) {
  if (!result || !range || range === '-') return null;
  const val = parseFloat(result);
  if (isNaN(val)) return null;

  const lines = range.split('\n');
  for (const line of lines) {
    // Handle "< 200"
    if (line.includes('<')) {
      const limit = parseFloat(line.split('<')[1].trim());
      if (!isNaN(limit)) return val >= limit ? 'H' : null;
    }
    // Handle "> 40"
    if (line.includes('>')) {
      const limit = parseFloat(line.split('>')[1].trim());
      if (!isNaN(limit)) return val <= limit ? 'L' : null;
    }
    // Handle "Up to 46"
    if (line.toLowerCase().includes('up to')) {
      const limit = parseFloat(line.toLowerCase().split('up to')[1].trim());
      if (!isNaN(limit)) return val > limit ? 'H' : null;
    }
    // Handle "14 - 16"
    if (line.includes('-')) {
      const parts = line.split('-').map(p => parseFloat(p.trim().replace(/[^\d.]/g, '')));
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        if (val < parts[0]) return 'L';
        if (val > parts[1]) return 'H';
        return null;
      }
    }
  }
  return null;
}
