import { motion } from 'motion/react';
import { Check, ShieldCheck, Zap, Star, Crown } from 'lucide-react';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useState } from 'react';

export default function Plans({ labProfile, setLabProfile }: { labProfile: any, setLabProfile: (p: any) => void }) {
  const [loading, setLoading] = useState<string | null>(null);

  const plans = [
    {
      id: '1year',
      name: 'Professional',
      price: '₹8,000',
      duration: '1 Year',
      features: ['Unlimited Reports', 'Full Branding', 'WhatsApp Integration', 'Priority Support'],
      icon: Zap,
      color: 'blue'
    },
    {
      id: '2year',
      name: 'Business',
      price: '₹14,000',
      duration: '2 Years',
      features: ['Everything in Professional', 'Multi-user Access', 'Advanced Analytics', 'Custom Domain'],
      icon: Star,
      color: 'emerald'
    },
    {
      id: '3year',
      name: 'Enterprise',
      price: '₹21,000',
      duration: '3 Years',
      features: ['Everything in Business', 'White-label Solution', 'API Access', 'Dedicated Account Manager'],
      icon: Crown,
      color: 'purple'
    }
  ];

  const handleUpgrade = async (plan: any) => {
    setLoading(plan.id);
    try {
      // In a real app, this would redirect to a payment gateway
      // For this demo, we'll create a pending payment request for the admin to approve
      const profileRef = doc(db, 'labProfiles', labProfile.uid);
      const updateData = {
        pendingPlan: plan.id,
        pendingPlanName: plan.name,
        pendingPlanPrice: plan.price,
        pendingPlanDuration: plan.duration,
        paymentStatus: 'pending',
        paymentRequestedAt: serverTimestamp()
      };
      await updateDoc(profileRef, updateData);
      setLabProfile({ ...labProfile, ...updateData });
      alert(`Request for ${plan.name} plan submitted! Please wait for admin approval.`);
    } catch (err) {
      console.error('Upgrade error:', err);
      alert('Failed to submit upgrade request.');
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="space-y-12 py-8">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-black text-slate-900 tracking-tight">Choose Your Plan</h2>
        <p className="text-slate-500 max-w-2xl mx-auto text-lg">
          Professional diagnostic reporting tools designed to help your lab grow. 
          Select a plan that fits your needs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <motion.div
            key={plan.id}
            whileHover={{ y: -10 }}
            className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden flex flex-col"
          >
            <div className={`p-8 bg-${plan.color}-50 border-b border-${plan.color}-100`}>
              <div className={`w-12 h-12 bg-${plan.color}-500 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-${plan.color}-200`}>
                <plan.icon className="h-6 w-6" />
              </div>
              <h3 className="text-2xl font-black text-slate-900">{plan.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-black text-slate-900">{plan.price}</span>
                <span className="text-slate-500 font-bold">/ {plan.duration}</span>
              </div>
            </div>

            <div className="p-8 flex-1 flex flex-col">
              <ul className="space-y-4 mb-10">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-600 font-medium">
                    <div className={`w-5 h-5 bg-${plan.color}-100 rounded-full flex items-center justify-center shrink-0`}>
                      <Check className={`h-3 w-3 text-${plan.color}-600`} />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleUpgrade(plan)}
                disabled={loading !== null || labProfile.paymentStatus === 'pending'}
                className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest transition-all shadow-lg ${
                  labProfile.paymentStatus === 'pending' && labProfile.pendingPlan === plan.id
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    : `bg-${plan.color}-600 text-white hover:bg-${plan.color}-700 shadow-${plan.color}-200`
                }`}
              >
                {loading === plan.id ? 'Processing...' : 
                 (labProfile.paymentStatus === 'pending' && labProfile.pendingPlan === plan.id) ? 'Pending Approval' : 'Upgrade Now'}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-blue-50 p-8 rounded-[2rem] border border-blue-100 flex flex-col md:flex-row items-center gap-6 justify-between">
        <div className="flex items-center gap-4">
          <div className="bg-blue-500 p-3 rounded-xl text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <h4 className="text-lg font-black text-blue-900">Secure Payment Guarantee</h4>
            <p className="text-blue-700 font-medium">Your data and payments are protected with enterprise-grade security.</p>
          </div>
        </div>
        <div className="text-blue-900 font-black text-sm uppercase tracking-widest">
          Trusted by 500+ Labs
        </div>
      </div>
    </div>
  );
}
